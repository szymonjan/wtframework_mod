contents = """
# Import your subpages Implementing an Interface in the 
# "__init__.py" so PageFactory will no about it's existence.
import tests.pages.GoogleSearchPage #@UnusedImport
import tests.pages.YahooSearchPage #@UnusedImport

"""